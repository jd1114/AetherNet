﻿namespace MareSynchronos.PlayerData.Pairs;

public enum PlayerChanges
{
    ModFiles = 1,
    ModManip = 2,
    Glamourer = 3,
    Customize = 4,
    Heels = 5,
    Honorific = 7,
    ForcedRedraw = 8,
    Moodles = 9,
    PetNames = 10,
}