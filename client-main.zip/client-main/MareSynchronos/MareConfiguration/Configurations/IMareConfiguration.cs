﻿namespace MareSynchronos.MareConfiguration.Configurations;

public interface IMareConfiguration
{
    int Version { get; set; }
}