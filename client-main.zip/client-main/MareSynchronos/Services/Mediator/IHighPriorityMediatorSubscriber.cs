﻿namespace MareSynchronos.Services.Mediator;

public interface IHighPriorityMediatorSubscriber : IMediatorSubscriber { }