# Mare Synchronos Dalamud Plugin

Available at [This dalamud Repo](https://raw.githubusercontent.com/Penumbra-Sync/repo/main/plogonmaster.json)

# [Mare Synchronos Discord](https://discord.gg/5HVveFefcB)

Readme TBD
