﻿namespace MareSynchronos.Services.Mediator;

public interface IMediatorSubscriber
{
    MareMediator Mediator { get; }
}