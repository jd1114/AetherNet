﻿namespace MareSynchronos.MareConfiguration.Models;

public enum DownloadSpeeds
{
    Bps,
    KBps,
    MBps
}