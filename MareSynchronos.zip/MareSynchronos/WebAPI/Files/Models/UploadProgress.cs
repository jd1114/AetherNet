﻿namespace MareSynchronos.WebAPI.Files.Models;

public record UploadProgress(long Uploaded, long Size);